module.exports = {
    AT:{
        apiKey: "86b44c09e15e457bed6f42bff41055cc49d22ca7305743f501c512b319062962",
        username: "sandbox",
        format: 'json'
    },
    pusher:{
       appId: '1022631',
       key: "a03cc380cf04e1bce05e",
       secret: "703664f00e6f53445a74",
       cluster: "ap2",
       encrypted: true
    }
}